package prw.edu.pl.ocadolicytacje.slack;

import lombok.Builder;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import prw.edu.pl.ocadolicytacje.infrastructure.entity.AuctionEntity;
import prw.edu.pl.ocadolicytacje.infrastructure.repository.AuctionRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ThreadService {
    private final SlackService slackService;
    private final AuctionRepository auctionRepository;

    static public String channelId = "D08PJ74E8TE"; // ID kanału

    public void createAuctionsThreads(LocalDate dateOfAuctionToStart) {
        System.out.println(">>> createAuctionsThreads called with date: " + dateOfAuctionToStart);

        LocalDateTime dateOfAuctionToStartAsLocalDateTime = dateOfAuctionToStart.atTime(12, 0);
        List<AuctionEntity> auctionsToStart = auctionRepository.findAllByStartDateTime(dateOfAuctionToStartAsLocalDateTime);
        System.out.println("Znaleziono aukcji: " + auctionsToStart.size());

        auctionsToStart.stream()
                .limit(3) // ustaw jeśli nie chcesz wypisywać wszystkich licytacji
                .forEach(auction -> {
                    String responseMessage = slackService.sendMessageToSlack(auction);
                    System.out.println(responseMessage);
                });
    }
}
