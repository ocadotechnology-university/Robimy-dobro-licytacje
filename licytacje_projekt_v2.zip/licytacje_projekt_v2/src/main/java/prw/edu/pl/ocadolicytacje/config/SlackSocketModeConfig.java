package prw.edu.pl.ocadolicytacje.config;

import com.slack.api.bolt.App;
import com.slack.api.bolt.AppConfig;
import com.slack.api.bolt.jakarta_socket_mode.SocketModeApp;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SlackSocketModeConfig {

    @Value("${slack.bot-token}")
    private String botToken;

    @Value("${slack.app-token}")
    private String appToken;

    @Bean
    public App slackApp() {
        AppConfig config = AppConfig.builder()
                .singleTeamBotToken(botToken)
                .build();
        return new App(config);
    }

    @Bean
    public SocketModeApp socketModeApp(App app) throws Exception {
        SocketModeApp socketModeApp = new SocketModeApp(appToken, app);
        socketModeApp.startAsync();
        return socketModeApp;
    }
}