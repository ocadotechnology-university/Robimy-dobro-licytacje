package prw.edu.pl.ocadolicytacje.infrastructure.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import prw.edu.pl.ocadolicytacje.infrastructure.entity.ParticipantEntity;

import java.util.Optional;

public interface ParticipantRepository extends JpaRepository<ParticipantEntity, Long> {
    Optional<ParticipantEntity> findByParticipantId(Long particiantId);
    Optional<ParticipantEntity> findBySlackUserId(String slackUserId);
}
