package prw.edu.pl.ocadolicytacje.infrastructure.exception;

public class GoogleSheetsSecurityException extends RuntimeException {
    public GoogleSheetsSecurityException(String message, Throwable cause) {
        super(message, cause);
    }
}