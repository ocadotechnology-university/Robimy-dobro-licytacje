package prw.edu.pl.ocadolicytacje.slack;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
@RequiredArgsConstructor
public class SlackUserService {

    private final SlackProperties slackProperties;
    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    public SlackUserInfo getUserInfo(String slackUserId) {
        String url = "https://slack.com/api/users.info?user=" + slackUserId;
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(slackProperties.getBotToken());
        HttpEntity<String> entity = new HttpEntity<>(headers);

        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

        try {
            JsonNode json = objectMapper.readTree(response.getBody());
            if (json.get("ok").asBoolean()) {
                JsonNode profile = json.get("user").get("profile");
                String firstName = profile.get("first_name").asText("Nieznany");
                String lastName = profile.get("last_name").asText("Użytkownik");

                return new SlackUserInfo(firstName, lastName);
            } else {
                System.out.println("❌ Błąd pobierania danych użytkownika Slack: " + json.get("error").asText());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new SlackUserInfo("Nieznany", "Użytkownik");
    }

    public record SlackUserInfo(String firstName, String lastName) {}
}

