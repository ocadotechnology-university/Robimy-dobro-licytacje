package prw.edu.pl.ocadolicytacje.infrastructure.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import prw.edu.pl.ocadolicytacje.infrastructure.entity.AuctionEntity;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AuctionRepository extends JpaRepository<AuctionEntity,Long> {
    List<AuctionEntity> findAllByStartDateTime(LocalDateTime auctionStartDateTime);

}
