package prw.edu.pl.ocadolicytacje.slack;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import prw.edu.pl.ocadolicytacje.infrastructure.entity.AuctionEntity;
import prw.edu.pl.ocadolicytacje.infrastructure.entity.BidEntity;
import prw.edu.pl.ocadolicytacje.infrastructure.repository.AuctionRepository;
import prw.edu.pl.ocadolicytacje.infrastructure.repository.BidRepository;


import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class SlackService {

    private final WebClient webClient = WebClient.create();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final BidRepository bidRepository;
    private final SlackProperties slackProperties;
    private final AuctionRepository auctionRepository;

    public String sendMessageToSlack(AuctionEntity auction) {
        // Przygotowanie treści wiadomości bez highestBidText
        String highestBidText = "\n*📈 Najwyższa oferta:* Brak ofert";

        Map<String, Object> messageBody = Map.of(
                "channel", ThreadService.channelId,
                "text", "Nowa aukcja: " + auction.getTitle(),
                "blocks", List.of(
                        Map.of(
                                "type", "section",
                                "text", Map.of(
                                        "type", "mrkdwn",
                                        "text", "*🏷️ Tytuł:* " + auction.getTitle()
                                                + "\n*📍 Miasto:* " + auction.getCity()
                                                + "\n*🕛 Start:* " + auction.getStartDateTime()
                                                + "\n*⏳ Koniec:* " + auction.getEndDateTime()
                                                + "\n*💰 Cena wywoławcza:* " + auction.getBasePrice() + " zł"
                                                + highestBidText
                                                + (auction.getModeratorEntity() != null ? "\n*🧑‍⚖️ Moderator:* " + auction.getModeratorEntity().getFirstName() + " " + auction.getModeratorEntity().getLastName() : "")
                                                + (auction.getSupplierEntity() != null ? "\n*🛍️ Dostawca:* " + auction.getSupplierEntity().getFirstName() + " " + auction.getSupplierEntity().getLastName() : "")
                                )
                        ),
                        Map.of(
                                "type", "section",
                                "text", Map.of(
                                        "type", "mrkdwn",
                                        "text", "*📝 Opis:*\n" + auction.getDescription()
                                )
                        ),
//                        Map.of(
//                                "type", "image",
//                                "image_url", auction.getPhotoUrl(),
//                                "alt_text", "Zdjęcie aukcji"
//                        ),
                        Map.of(
                                "type", "actions",
                                "elements", List.of(
                                        Map.of(
                                                "type", "button",
                                                "text", Map.of(
                                                        "type", "plain_text",
                                                        "text", "🔨 Licytuj"
                                                ),
                                                "action_id",  "open_bid_modal",
                                                "value", String.valueOf(auction.getAuctionId())
                                        )
                                )
                        )
                )
        );

        try {
            // Wysyłanie wiadomości
            String response = webClient.post()
                    .uri("https://slack.com/api/chat.postMessage")
                    .header("Authorization", "Bearer " + slackProperties.getBotToken())
                    .header("Content-Type", "application/json")
                    .bodyValue(messageBody)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            // Parsowanie odpowiedzi JSON, aby uzyskać ts
            Map<String, Object> jsonResponse = objectMapper.readValue(response, Map.class);
            if (!(Boolean) jsonResponse.getOrDefault("ok", false)) {
                return "⚠️ Błąd Slack API: " + jsonResponse.get("error");
            }

            // Zapisz ts wiadomości do późniejszej edycji
            String messageTs = (String) jsonResponse.get("ts");
            auction.setSlackMessageTs(messageTs);
            auctionRepository.save(auction);

            // Zwróć ts, który będzie potrzebny do aktualizacji wiadomości
            return messageTs;

        } catch (Exception e) {
            return "❌ Błąd przy wysyłaniu wiadomości: " + e.getMessage();
        }
    }


    public void openBidModal(String triggerId, String auctionId) {
        Map<String, Object> modalView = new HashMap<>();
        modalView.put("type", "modal");
        modalView.put("title", Map.of("type", "plain_text", "text", "Złóż ofertę"));
        modalView.put("submit", Map.of("type", "plain_text", "text", "Wyślij"));
        modalView.put("close", Map.of("type", "plain_text", "text", "Anuluj"));
        modalView.put("callback_id", "submit_bid");
        modalView.put("private_metadata", auctionId);
        modalView.put("blocks", List.of(
                Map.of(
                        "type", "input",
                        "block_id", "bid_amount_block",
                        "label", Map.of("type", "plain_text", "text", "Kwota oferty (zł)"),
                        "element", Map.of(
                                "type", "plain_text_input",
                                "action_id", "bid_amount_input"
                        )
                )
        ));


        try {
            String response = webClient.post()
                    .uri("https://slack.com/api/views.open")
                    .header("Authorization", "Bearer " + slackProperties.getBotToken())
                    .header("Content-Type", "application/json")
                    .bodyValue(Map.of(
                            "trigger_id", triggerId,
                            "view", modalView
                    ))
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

//            System.out.println("🟢 Slack views.open response: " + response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateHighestBidMessage(String messageTs, BigDecimal highestBid, String bidderMention) {
        try {
            System.out.println("🔄 Rozpoczynam aktualizację wiadomości w Slacku dla ts: " + messageTs);

            // 1. Pobierz wiadomość z historią
            String historyResponse = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .scheme("https")
                            .host("slack.com")
                            .path("/api/conversations.history")
                            .queryParam("channel", ThreadService.channelId)
                            .queryParam("latest", messageTs)
                            .queryParam("limit", "1")
                            .queryParam("inclusive", "true")
                            .build())
                    .header("Authorization", "Bearer " + slackProperties.getBotToken())
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            System.out.println("📥 Odpowiedź z Slack API (history): " + historyResponse);

            Map<String, Object> historyJson = objectMapper.readValue(historyResponse, Map.class);

            if (!(Boolean) historyJson.getOrDefault("ok", false)) {
                System.out.println("⚠️ Błąd Slack API (history): " + historyJson.get("error"));
                return;
            }

            List<Map<String, Object>> messages = (List<Map<String, Object>>) historyJson.get("messages");
            if (messages == null || messages.isEmpty()) {
                System.out.println("❌ Nie znaleziono wiadomości Slack do aktualizacji (pusta lista).");
                return;
            }

            Map<String, Object> message = messages.get(0);
            List<Map<String, Object>> blocks = (List<Map<String, Object>>) message.get("blocks");

            boolean updated = false;

            // 2. Znajdź i zaktualizuj tylko fragment tekstu z ofertą
            for (Map<String, Object> block : blocks) {
                if ("section".equals(block.get("type"))) {
                    Map<String, Object> text = (Map<String, Object>) block.get("text");
                    if (text != null && "mrkdwn".equals(text.get("type"))) {
                        String originalText = (String) text.get("text");
                        System.out.println("✏️ Oryginalny tekst: " + originalText);

                        // Szukamy linijki zawierającej "Najwyższa oferta:"
                        Pattern pattern = Pattern.compile("\\*.*?Najwyższa oferta:\\*.*?(\\n|$)");
                        Matcher matcher = pattern.matcher(originalText);

                        if (matcher.find()) {
                            String updatedText = matcher.replaceAll(
                                    "*📈 Najwyższa oferta:* " + highestBid + " zł _(od " + bidderMention + ")_\n"
                            );
                            text.put("text", updatedText);
                            System.out.println("✅ Zaktualizowany tekst: " + updatedText);
                            updated = true;
                            break;
                        }
                    }
                }
            }

            if (!updated) {
                System.out.println("⚠️ Nie znaleziono sekcji do aktualizacji.");
                return;
            }

            // 3. Wyślij zaktualizowaną wiadomość
            Map<String, Object> updatedMessage = Map.of(
                    "channel", ThreadService.channelId,
                    "ts", messageTs,
                    "blocks", blocks
            );

            System.out.println("📤 Wysyłam zaktualizowaną wiadomość do Slacka...");

            String updateResponse = webClient.post()
                    .uri("https://slack.com/api/chat.update")
                    .header("Authorization", "Bearer " + slackProperties.getBotToken())
                    .header("Content-Type", "application/json")
                    .bodyValue(updatedMessage)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            System.out.println("📬 Odpowiedź z Slack API (update): " + updateResponse);

            Map<String, Object> jsonResponse = objectMapper.readValue(updateResponse, Map.class);
            if (!(Boolean) jsonResponse.getOrDefault("ok", false)) {
                System.out.println("⚠️ Błąd Slack API (update): " + jsonResponse.get("error"));
            } else {
                System.out.println("✅ Wiadomość została pomyślnie zaktualizowana w Slacku.");
            }

        } catch (Exception e) {
            System.out.println("❌ Wyjątek podczas aktualizacji wiadomości: " + e.getMessage());
            e.printStackTrace();
        }
    }





}

