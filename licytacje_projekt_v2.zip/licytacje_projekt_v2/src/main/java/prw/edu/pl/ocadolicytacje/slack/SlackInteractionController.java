package prw.edu.pl.ocadolicytacje.slack;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URLDecoder;
import java.util.List;
import java.util.Map;


@RestController
@RequiredArgsConstructor
public class SlackInteractionController {

    private final SlackService slackService;
    private final BidService bidService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @PostMapping("/slack/interactive")
    public ResponseEntity<?> handleSlackInteraction(@RequestBody String body) {
        try {
            String payload = body;

            if (payload.startsWith("payload=")) {
                payload = URLDecoder.decode(payload.substring(8), "UTF-8");
            }

            Map<String, Object> data = objectMapper.readValue(payload, Map.class);

            String type = (String) data.get("type");

            switch (type) {
                case "block_actions" -> {
                    List<Map<String, Object>> actions = (List<Map<String, Object>>) data.get("actions");
                    String actionId = (String) actions.get(0).get("action_id");

                    if ("open_bid_modal".equals(actionId)) {
                        String triggerId = (String) data.get("trigger_id");
                        String auctionId = (String) actions.get(0).get("value"); // Tu trzymamy auction_id
                        System.out.println("🔧 Opening modal with auctionId: " + auctionId);
                        slackService.openBidModal(triggerId, auctionId);
                    }
                }

                case "view_submission" -> {
                    bidService.processBidSubmission(data);
                    return ResponseEntity.ok(Map.of("response_action", "clear")); // Slack oczekuje odpowiedzi
                }

                case "url_verification" -> {
                    String challenge = (String) data.get("challenge");
                    return ResponseEntity.ok(challenge);
                }
            }

            return ResponseEntity.ok().build();

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }
}

