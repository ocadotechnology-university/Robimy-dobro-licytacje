package prw.edu.pl.ocadolicytacje.config;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import prw.edu.pl.ocadolicytacje.infrastructure.api.AuctionCsvImportService;

@Component
@RequiredArgsConstructor
public class StartupRunner implements ApplicationRunner {
    private final AuctionCsvImportService auctionCsvImportService;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        auctionCsvImportService.saveImportedModeratorSupplierAuctionEntities();
    }
}
