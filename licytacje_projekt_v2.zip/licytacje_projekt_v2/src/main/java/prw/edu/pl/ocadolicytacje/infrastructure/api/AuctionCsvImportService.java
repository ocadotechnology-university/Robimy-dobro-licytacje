package prw.edu.pl.ocadolicytacje.infrastructure.api;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import prw.edu.pl.ocadolicytacje.infrastructure.entity.AuctionEntity;
import prw.edu.pl.ocadolicytacje.infrastructure.entity.ModeratorEntity;
import prw.edu.pl.ocadolicytacje.infrastructure.entity.SupplierEntity;
import prw.edu.pl.ocadolicytacje.infrastructure.exception.DataRetrievalIOException;
import prw.edu.pl.ocadolicytacje.infrastructure.exception.GoogleSheetsSecurityException;
import prw.edu.pl.ocadolicytacje.infrastructure.repository.AuctionRepository;
import prw.edu.pl.ocadolicytacje.infrastructure.repository.ModeratorRepository;
import prw.edu.pl.ocadolicytacje.infrastructure.repository.SupplierRepository;

import java.io.IOException;
import java.math.BigDecimal;
import java.security.GeneralSecurityException;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class AuctionCsvImportService {
    public static final String SECURITY_MESSAGE = "Wystąpił wyjątek związany z bezpieczeństwem, podczas pobierania danych z Google Sheet";
    public static final String DATA_RETIVAL_MESSAGE = "Wystąpił generalny wyjatek związany z odczytem danych z Google Sheet";
    private final ModeratorRepository moderatorRepository;
    private final SupplierRepository supplierRepository;
    private final AuctionRepository auctionRepository;
    private final GoogleSheetReader googleSheetReader;
    private final AuctionSheetMapper auctionSheetMapper;

    public void saveImportedModeratorSupplierAuctionEntities() {

        List<List<Object>> csvData = null;
        try {
            csvData = googleSheetReader.getCsvData();
        } catch (GeneralSecurityException e) {
            log.warn(SECURITY_MESSAGE);
            throw new GoogleSheetsSecurityException(SECURITY_MESSAGE, e);
        } catch (IOException e) {
            log.warn(DATA_RETIVAL_MESSAGE);
            throw new DataRetrievalIOException(DATA_RETIVAL_MESSAGE, e);
        }
        List<AuctionCsvRowDto> auctionCsvRowDtoList = auctionSheetMapper.map(csvData);

        for (AuctionCsvRowDto auctionCsvRowDto : auctionCsvRowDtoList) {
            ModeratorEntity moderatorEntity = createModeratorEntity(auctionCsvRowDto.getModeratorFullName());
            moderatorRepository.save(moderatorEntity);
            SupplierEntity supplierEntity = createSupplierEntity(auctionCsvRowDto.getSupplierFullName());
            supplierRepository.save(supplierEntity);
            AuctionEntity auctionEntity = createAuctionEntity(
                    auctionCsvRowDto.getAuctionTitle(),
                    auctionCsvRowDto.getAuctionDescription(),
                    auctionCsvRowDto.getPhotoUrl(),
                    auctionCsvRowDto.getCity(),
                    auctionCsvRowDto.getBasePrice(),
                    auctionCsvRowDto.getAuctionStartDateTime(),
                    auctionCsvRowDto.getAuctionEndDateTime()
            );
            auctionRepository.save(auctionEntity);
        }
    }

    private AuctionEntity createAuctionEntity(String auctionTitle, String auctionDescription, String photoUrl, String city, BigDecimal basePrice, LocalDateTime auctionStartDateTime, LocalDateTime auctionEndDateTime) {
        return AuctionEntity.builder()
                .title(auctionTitle)
                .description(auctionDescription)
                .photoUrl(photoUrl)
                .city(city)
                .basePrice(basePrice)
                .startDateTime(auctionStartDateTime)
                .endDateTime(auctionEndDateTime)
                .build();
    }

    private ModeratorEntity createModeratorEntity(String moderatorFullName) {
        final String[] fullNameSplited = moderatorFullName.trim().split("\\s+", 2);
        return ModeratorEntity.builder()
                .firstName(fullNameSplited[0])
                .lastName(fullNameSplited[1])
                .build();
    }

    private SupplierEntity createSupplierEntity(String supplierFullName) {
        final String[] fullNameSplited = supplierFullName.trim().split("\\s+", 2);
        return SupplierEntity.builder()
                .firstName(fullNameSplited[0])
                .lastName(fullNameSplited[1])
                .build();
    }

}
