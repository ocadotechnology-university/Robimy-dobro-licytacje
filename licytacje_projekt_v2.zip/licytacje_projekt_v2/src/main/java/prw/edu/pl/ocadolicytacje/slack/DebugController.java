package prw.edu.pl.ocadolicytacje.slack;

import com.google.api.client.util.DateTime;
import lombok.RequiredArgsConstructor;
import java.time.LocalDate;

import org.springframework.cglib.core.Local;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequiredArgsConstructor
@RequestMapping("/debug")
public class DebugController {
    private final ThreadService threadService;

//    public LocalDate dateTime = LocalDate.now();
    public LocalDate date = LocalDate.parse("2025-10-01");

    @GetMapping("/start-auctions")
    public void start() {
        threadService.createAuctionsThreads(date);
    }
}