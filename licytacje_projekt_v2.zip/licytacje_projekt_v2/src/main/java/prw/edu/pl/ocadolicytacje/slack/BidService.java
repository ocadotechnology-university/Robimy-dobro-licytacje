package prw.edu.pl.ocadolicytacje.slack;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import prw.edu.pl.ocadolicytacje.infrastructure.entity.AuctionEntity;
import prw.edu.pl.ocadolicytacje.infrastructure.entity.BidEntity;
import prw.edu.pl.ocadolicytacje.infrastructure.entity.ParticipantEntity;
import prw.edu.pl.ocadolicytacje.infrastructure.repository.AuctionRepository;
import prw.edu.pl.ocadolicytacje.infrastructure.repository.BidRepository;
import prw.edu.pl.ocadolicytacje.infrastructure.repository.ParticipantRepository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class BidService {

    private final AuctionRepository auctionRepository;
    private final ParticipantRepository participantRepository;
    private final BidRepository bidRepository;
    private final SlackUserService slackUserService;
    private final SlackService slackService;

    public void processBidSubmission(Map<String, Object> payload) {
        try {

            Map<String, Object> user = (Map<String, Object>) payload.get("user");
            String slackUserId = (String) user.get("id");


            Map<String, Object> view = (Map<String, Object>) payload.get("view");
            String auctionIdStr = (String) view.get("private_metadata");
            Long auctionId = Long.parseLong(auctionIdStr);

            Map<String, Object> state = (Map<String, Object>) view.get("state");
            Map<String, Object> values = (Map<String, Object>) state.get("values");
            Map<String, Object> bidBlock = (Map<String, Object>) values.get("bid_amount_block");
            Map<String, Object> bidInput = (Map<String, Object>) bidBlock.get("bid_amount_input");

            System.out.println("📦 Odczytane private_metadata: [" + auctionIdStr + "]");

            String bidAmountStr = (String) bidInput.get("value");
            if (bidAmountStr == null || bidAmountStr.trim().isEmpty()) {
                throw new RuntimeException("Kwota oferty nie może być pusta.");
            }
            BigDecimal bidAmount = new BigDecimal(bidAmountStr);

            // Pobranie najwyższej oferty dla danej aukcji
            BigDecimal currentHighestBid = bidRepository
                    .findTopByAuctionEntityAuctionIdOrderByBidValueDesc(auctionId)
                    .map(BidEntity::getBidValue)
                    .orElse(BigDecimal.ZERO);

            // Walidacja: nowa oferta musi być wyższa
            if (bidAmount.compareTo(currentHighestBid) <= 0) {
                throw new RuntimeException("Oferta musi być wyższa niż aktualna najwyższa oferta: " + currentHighestBid + " zł");
            }


            // Sprawdzanie, czy uczestnik istnieje w bazie danych
            Optional<ParticipantEntity> participantOpt = participantRepository.findBySlackUserId(slackUserId);
            ParticipantEntity participant;

            if (participantOpt.isEmpty()) {
                System.out.println("🔔 Tworzenie nowego uczestnika dla Slack ID: " + slackUserId);


                SlackUserService.SlackUserInfo slackUser = slackUserService.getUserInfo(slackUserId);

                participant = new ParticipantEntity();
                participant.setSlackUserId(slackUserId);
                participant.setFirstName(slackUser.firstName());
                participant.setLastName(slackUser.lastName());

                participant = participantRepository.save(participant);
            } else {
                // Uczestnik już istnieje, przypisanie go do zmiennej
                participant = participantOpt.get();
            }

            Optional<AuctionEntity> auctionOpt = auctionRepository.findById(auctionId);
            if (auctionOpt.isEmpty()) {
                throw new RuntimeException("Nie znaleziono aukcji o ID: " + auctionId);
            }
            BidEntity bid = new BidEntity();
            bid.setAuctionEntity(auctionOpt.get());
            bid.setParticipantEntity(participant);
            bid.setBidValue(bidAmount);
            bid.setBidDateTime(LocalDateTime.now());

            bidRepository.save(bid);
            System.out.println("✅ Zapisano ofertę: " + bidAmount + " zł dla aukcji ID " + auctionId);

            // Aktualizacja wiadomości na Slacku z nową najwyższą ofertą
            AuctionEntity auction = auctionOpt.get();
            String slackMessageTs = auction.getSlackMessageTs();

            String bidderMention = "<@" + participant.getSlackUserId() + ">";
            if (slackMessageTs != null && !slackMessageTs.isBlank()) {
                slackService.updateHighestBidMessage(slackMessageTs, bidAmount, bidderMention);
            }


        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("❌ Błąd przy przetwarzaniu oferty: " + e.getMessage());
        }
    }
}
