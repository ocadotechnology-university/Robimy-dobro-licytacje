package prw.edu.pl.ocadolicytacje.infrastructure.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import prw.edu.pl.ocadolicytacje.infrastructure.entity.AuctionEntity;
import prw.edu.pl.ocadolicytacje.infrastructure.entity.BidEntity;

import java.util.List;
import java.util.Optional;

public interface BidRepository extends JpaRepository<BidEntity, Long> {
    List<BidEntity> findByAuctionEntityAuctionIdOrderByBidValueDesc(Long auctionId);
    Optional<BidEntity> findTopByAuctionEntityAuctionIdOrderByBidValueDesc(Long auctionId);

//    @Query("SELECT b FROM BidEntity b WHERE b.auctionEntity = :auction ORDER BY b.bidValue DESC")
    Optional<BidEntity> findTopByAuctionEntityOrderByBidValueDesc(AuctionEntity auction);
}

