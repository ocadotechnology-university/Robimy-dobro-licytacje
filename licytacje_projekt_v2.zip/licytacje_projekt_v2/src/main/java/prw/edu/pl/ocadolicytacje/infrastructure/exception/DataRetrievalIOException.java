package prw.edu.pl.ocadolicytacje.infrastructure.exception;

public class DataRetrievalIOException extends RuntimeException {

    public DataRetrievalIOException(String message) {
        super(message);
    }

    public DataRetrievalIOException(String message, Throwable cause) {
        super(message, cause);
    }
}
