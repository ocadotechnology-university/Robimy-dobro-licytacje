package prw.edu.pl.ocadolicytacje;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OcadoLicytacjeApplicationTests {

    @Test
    void contextLoads() {
    }

}
